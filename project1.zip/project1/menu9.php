<html>
<head>
<title>Clicking Clean</title>
<style>
  body {
   background-color: light-grey ;
   text-align: left;
   margin-right: 35%;
}

  h1 {

   text-align: left;
   color:#004d00;

}
  h3 {
  
  text-align: left;

}
img.click {
   
  float:left;
  margin-left: 100px;
  width:800px;
  height: 300px;
  border-radius:20px;
}
</style>
</head>
<body>
<img class="click" src="http://www.pressenza.com/wp-content/uploads/2015/05/ClickCleanOpenSpace-720x270.jpg">
<?php require 'hello.php';?>



<h1>Clicking Clean</h1>
A Guide to Building the Green Internet
Publication - 12 May, 2015
<h3><p>While there may be significant energy efficiency gains from moving our lives online, the explosive growth of our digital lives is outstripping those gains. Publishing conglomerates now consume more energy from their data centers than their printing presses. Greenpeace has estimated that the aggregate electricity demand of our digital infrastructure back in 2011 would have ranked sixth in the world among countries.<br>
<p>The rapid transition to streaming video models, as well as tablets and other thin client devices that supplant on-device storage with the cloud, means more and more demand for data center capacity, which will require more energy to power.<br>
<p>The transition to online distribution models, such as video streaming, appears to deliver a reduction in the carbon footprint over traditional models of delivery. However, in some cases, this shift may simply be enabling much higher levels of consumption, ultimately increasing the total amount of electricity consumed and the associated pollution from electricity generation.<br> Unless leading internet companies find a way to leapfrog traditional, polluting sources of electricity, the convenience of streaming could cause us to increase our carbon footprint.<br></h3>


</body>
</html>