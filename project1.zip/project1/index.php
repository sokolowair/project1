<?php 
  
 $tmp=file_get_contents("header.html");
 echo $tmp;


?>
<?php 

 $tmp=file_get_contents("menu.html");
 echo $tmp;
   

?> 
 <div style="width:100%">
    <div id="content">
	<a href="http://sokolowair.comxa.com/project1/menu1.php"><img src="http://people.rit.edu/njg7832/140/project3/images/green3.jpg"></a>
	<a href="http://sokolowair.comxa.com/project1/menu2.php"><img src="http://lh3.ggpht.com/piHC7dCuI4ulT8RCrf6t0TjMZImLgyaVaFvq8XPF5Qpzk3jXaHegmx7-t7IorgYiGRoPmmUVA6d0CtR-9lJv603UDA=s176"></a>
	<a href="http://sokolowair.comxa.com/project1/menu3.php"><img src="http://www.energyportal.sg/images/energy_101.png"></a>
	<a href="http://sokolowair.comxa.com/project1/menu4.php"><img src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSL3YIklPaDS9Ir5FykuaJS8yzCk1R4c3yDcv0hv0m1le4kUvWh-Q"></a>
	<a href="http://sokolowair.comxa.com/project1/menu5.php"><img src="http://c1cleantechnicacom.wpengine.netdna-cdn.com/files/2014/04/wind-turbines17.jpg"></a>
	<a href="http://sokolowair.comxa.com/project1/menu6.php"><img src="http://publications.arup.com/~/media/Publications/Images/G/geothermal-energy-promo-658x930.ashx"></a>
	<a href="http://sokolowair.comxa.com/project1/menu7.php"><img src="http://berc.berkeley.edu/wp-content/uploads/2015/04/windsolar.jpg"></a>
	<a href="http://sokolowair.comxa.com/project1/menu8.php"><img src="http://www.energymatters.com.au/wp-content/uploads/2015/09/energy-revolution-2015.jpg"></a>
	<a href="http://sokolowair.comxa.com/project1/menu9.php"><img src="http://www.greenpeace.org/usa/wp-content/uploads/legacy/clickclean/images/2015clickcleanreport.jpg?a1481f"></a>
        <a href="http://sokolowair.comxa.com/project1/menu10.php"><img src="http://www.greenpeace.org/eu-unit/Global/eu-unit/image/2015/20151006%20Map%20GMO%20cultivation%20opt%20out.jpg"></a>

  </div>
<div id="rightside">
   




<div id="menu">
   <?php require 'login.php'; ?>
  </div>
 <div id="menu">
   <?php require 'hello.php'; ?>
  </div>
 </div>
</div>
  <div id="footer">

<li style="color: #cc66ff;">
     <span>�</span> 
         <strong> Sokolowair</strong> 
                  <span>e-mail:sokolow1507@gmail.com</span> 
                            <span>2015</span>
</li>
</div>
 </body>

</html>