<?php

$c=new mysqli("mysql9.000webhost.com","a3079210_sok","12345qwerty","a3079210_green");

$c->close();

?>