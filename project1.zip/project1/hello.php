<html>
<head>
<style>
 body {
   widht: 150px;
   height: 400px;
   text-align: right;
   margin-right: 15px;
   float:center;
}


</style>

</head>
<body>
<script type="text/javascript" src="http://oilprice.com/widgets/energyproduction.js"></script><noscript><!--Please Enable Javascript for this <a href="http://oilprice.com/Energy/Energy-General">Energy</a> widget to work--></noscript>
</body>
</html>